<?php
//Original Array on which operations is to be perform

$original_array = 0;
$someString = "hello";
echo $original_array

function fibo($arr){
for($hola=1;$hola > 0; $i++){
    echo $i;
}
return $arr
}

?>